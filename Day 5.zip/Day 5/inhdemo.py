class A:
    def showA(self):
        print('Hello A');

class B:
    def showB(self):
        print('hello B');
class C(A,B):
    def showC(self):
        print('hello c');

b1=C();
b1.showA()
b1.showB()
b1.showC()
