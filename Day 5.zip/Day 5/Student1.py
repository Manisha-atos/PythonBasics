class Student1:
    name=''
    std=0
    def __init__(self):
        print('def cons');


    '''def __init__(self,name,std):
        self.name=name
        self.std=std;'''
        
    def show(self):
        print(self.name)
        print(self.std)
        print('hello');
    
    '''def show(self,a):
        print(a);'''

'''name=input('enter name')
std=int(input('enter div'));
s=Student1(name,std)
#s.getData(name,std)
s.show()'''
s1=Student1()
#s1.show('hello....')
s1.show()




        