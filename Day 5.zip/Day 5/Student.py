class Student:
    name=''
    std=0
    def getData(self,a,b):
        self.name=a
        self.std=b;
    def display():
        a=100
        print(a);
    
        

        
    def show(self):
        print(self.name)
        print(self.std)
        print('hello')

name=input('enter name')
std=int(input('enter div'));
s=Student()
s.getData(name,std)
s.show()
s.display()



        