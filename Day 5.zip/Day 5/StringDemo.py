s1="hello"
s2="hello"
s3="Hello"
print(id(s1))
print(id(s2))
print(s1)
print(s1.upper())
print(s1.index('l'))
#print(s1.index('H'))
print(s1.capitalize())
print(s1.count('l'))
print(s1.startswith('o'))
print(s1.endswith('O'))
print(s1 is s2)
print(s1 is s3)
print(s1>s3)
print(s1.replace('l','$'))
#print(s1.spli