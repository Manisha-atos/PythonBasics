class Employee:
    #unable to use def and para constructor
    name='';
    __age=0;

    def __init__(self):
        Employee.name='manisha kiran'
        Employee.age=33;
        print('def constructor');  
    def display(self):
        print(self.name)
        print(self.age)
        print("hello");      
    
    '''def __init__(self,name,age):
        self.name=name
        self.age=age
    def display(self):
        print(self.name)
        print(self.age)
        print("hello");
e1=Employee('manisha',33)
e1.display()'''
e2=Employee()
e2.display()
print(e2.__age)

class car:  
    def __init__(self,modelname, year):  
        self.modelname = modelname  
        self.year = year  
    def display(self):  
        print(self.modelname,self.year)  
  
c1 = car("Toyota", 2016)  
c1.display()  