class A:
    _x=100
    def show(self):
        print('x=%d' % self._x)
        print('class A');
class B(A):
    def show(self):
        print('class B');

class C(B):
    def show(self):
        print('class C')

b=A()
b.show()
print(b._x)
b=B()
b.show()
b=C()
b.show();