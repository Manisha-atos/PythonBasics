from multipledispatch import dispatch
class Calc:
    
    def add(self,datatype,*args):
        sum=0
        if datatype == 'int':
            sum = 0;
        if datatype=='str':
            sum=''
        for x in args:
            sum=sum+x;
        print(sum)

    @dispatch(int, int)
    def product(first, second):
        result = first*second
        print(result)
 
# passing two parameters
 
 
    @dispatch(int, int, int)
    def product(first, second, third):
        result = first * second * third
        print(result)

    @dispatch(float, int, float)
    def product(first, second, third):
        result = first * second * third
        print(result)
 
    
c=Calc()
c.add('int', 5, 6)
c.add('str','a','nb','ddd')
c.product(2,2)
c.product(2.2,11,3.3)
