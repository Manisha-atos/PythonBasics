import math
import abc
from abc import ABC, abstractmethod  
class Shape(ABC):
    @abstractmethod
    def area(self):
        pass;
        
class Circle(Shape):
    def area(self):
        print(math.pi*2.2*2.2);

class Triangle(Shape):
    def area1(self):
        area1=0.5*4*5
        print(area1)

c=Circle()
c.area()

t=Triangle()
t.area1()

#s=Shape()
#s.area()



