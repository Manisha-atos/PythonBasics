data1=(1,2,3,4)
data2=('x','y','z')
print(data1)
print(data2)
data3=data1+data2
print(data3)
print(data2[0:2])
print(data2[-3:-1])
print(data2[:2])
print(data2[-3:])
print(data2[-2:])
print(data2[-5:])
print(data2*2)
'''
data1[0]=5
print(data1)
'''
#del data1[0]
del data1
print(data1)
