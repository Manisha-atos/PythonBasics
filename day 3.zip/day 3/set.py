s1={1,2,9,3,1,3,7,9,3,1,3,2}
s2={5,8,4,3,7,8}
print(s1)
print(s2)
print(s1 & s2)
print(s1.intersection(s2))
print(s1 | s2)
print(s1.union(s2))
print(s1-s2)
print(s1.difference(s2))
print(s2-s1)
print(s2.difference(s1))


A = {1, 2, 3, 4, 5}

B = {4, 5, 6, 7, 8}
print(A | B)
print(A & B)
print(A - B)
print(A ^ B)


A = {1, 2, 3, 4, 5}

B = {4, 5, 6, 7, 8}
print(A.symmetric_difference(B))

a={1,2,3,4,4}
print(a)

b = set([1,2,2,2])
print(b)