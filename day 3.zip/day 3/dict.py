data1={'Id':100,'Name':'ravi','profession':'analyst'}
print(len(data1));
data1.clear();
print(data1);
data2={'Id':101,'Name':'raju','profession':'tester'}
print(type(data1))
'''
print(data1);
print(data1['Id']);
print(data2);
data2['Name']='Kiran'
print("ename",data2['Name']);
print(data1.keys());
print(data1.values());
print(data1.items());
print(data1.get('profession'));


print(data2.get('Id'));
del data2['Name'];
print(data2);
del data2;
print(data2);

print(len(data1));
data1.clear();
print(data1);
data1['location']='Chennai'
print(data1);
'''
