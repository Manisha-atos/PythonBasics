
def getData(a,b):
    global x
    global y
    x=a
    y=b;
    

def div():
    getData(4,0)
    print(x/y);

a=int(input('enter a'))
b=int(input('enter b'))
try:
#getData(a,b)
    div()

except Exception as e:
    print(e)




    