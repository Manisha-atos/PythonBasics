'''s1={1,2,3}
s2={2,3,4}
print(s1.union(s2))
print(s1.intersection(s2))
print(s1.difference(s2))
print(s1.symmetric_difference(s2))'''


numbers = [3, 5, 4,1, 7, 3, 9]  
num = [n**2 for n in numbers if n%2==0]  
print(num)

Person = ["Piyali", "Hiya", "Rudrashish", "Badsha", "Lipi"]  
newlist = [x for x in Person if "i" in x]  
print(newlist) 