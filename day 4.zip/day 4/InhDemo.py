class A:
    def showA(self):
        print('hello A');
class B (A):
    def showB(self):
        print('hello B');
b=B()
b.showA()
b.showB()
