import pandas as pd
xls = pd.ExcelFile('C:/temp/Training/Python Basic/Python Demos/day3/student.xls')
df1 = pd.read_excel(xls, 'student',usecols='A:B')
print(df1)
df2 = pd.read_excel(xls, 'titanic',usecols='A:B')
print(df2)