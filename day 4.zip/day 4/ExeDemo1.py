'''string = "Python Exceptions"  
  
for s in string:  
    if (s != o:  
        print( s '''
'''l1=[1,2,3]
for x in range(len(l1)+1):
    print(l1[x]);'''
#print(x)

l1=[1,2,3]
try:
    for x in range(len(l1)+1):
        print(l1[x]);
except:
    print('index mis match error');
a=4
b=2
try:
    if(b==0):
        raise Exception('divide by zero error');
    print(a/b)
except ZeroDivisionError:
    print('ZeroDivisionError Occurred and Handled')
print(a+b)
