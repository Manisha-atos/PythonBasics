a=int(input('enter a'))
b=int(input('enter b'))
#try:
if (b==0):
    raise ZeroDivisionError("Divide by zero error!!!!!!")
else:
    print(a/b)
'''except ZeroDivisionError as e:
    print (e)'''


print('end of program')