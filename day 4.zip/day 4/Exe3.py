
try:
    a=int(input('enter a'))
    b=int(input('enter b'))
    print(a+b)
    print(a-b)
    print(a/b)
except ZeroDivisionError as e:
    print("ZeroDivisionError Occurred and Handled")
    print(e)
except NameError as e:
    print("NameError Occurred and Handled")
    print(e)
except :
    print("sorry some error")

