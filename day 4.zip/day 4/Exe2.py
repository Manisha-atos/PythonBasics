
try:
    a=int(input('enter a'))
    b=int(input('enter b'))
except:
    print("invalid data type")
    a=0
    b=0
print(a+b)
s={1,2,3,4}
print(s)
try:
   print(a/b)
except:
    print('some error plz try again later')
print(a+b)
print(a-b)