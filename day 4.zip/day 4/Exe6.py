
try:
    a=int(input('enter a'))
    b=int(input('enter b'))
    print(a/b)
    
except:
    print("some error")
else:
    print(a+b)
    print(a+b)
    print(a-b)
s={1,2,3,4}
print(s)
