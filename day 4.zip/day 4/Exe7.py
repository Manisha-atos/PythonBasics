
try:
    a=int(input('enter a'))
    b=int(input('enter b'))
    print(a/b)
except TypeError as e:
    print(e)
finally:
    print('finally block')
    a=0
    b=0
    
print(a+b)
print(a+b)
print(a-b)
s={1,2,3,4}
print(s)
