import math
from abc import ABC, abstractmethod  
class Shape:
    def area(self):
        pass;
class Circle(Shape):
    def area1(self):
        print(math.pi*2.2*2.2);
c=Circle()
c.area1()



