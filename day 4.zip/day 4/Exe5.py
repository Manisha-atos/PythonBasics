
try:
    a=int(input('enter a'))
    b=int(input('enter b'))
    try:
        print(a/b)
    except ZeroDivisionError as e:
        print(e)
except:
    print(" outer block invalid data type")
    a=0
    b=0
print(a+b)
print(a-b)
print(a*b)