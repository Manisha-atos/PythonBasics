a=4
b=2
print(a+b)
s={1,2,3,4}
print(s)
try:
    if(a/b>0):
        print('asas');
except:
    print('some error plz try again later')
print(a+b)
print(a-b)