
try:
    a=int(input('enter a'))
    b=int(input('enter b'))
    print(a+b)
    print(a-b)
    print(a/b)
except (ZeroDivisionError,ValueError,NameError):
    print("ZeroDivisionError|Value|Name Occurred and Handled")
except:
    print("sorry some error")

