import json
f=open("emp.json","r")
obj=f.read();
result=json.loads(obj);
print(result)
print(result["Records"][1])
