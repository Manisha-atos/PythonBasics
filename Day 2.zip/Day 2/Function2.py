def add(a,b=10):
    print("a=%d" % a)
    print("b=%d" % b)
    return a+b;

print(add(1,2))
print(add(a=19))
#varray demo
def sum(*args):
  for x in args:
     print(x);
  '''  total=""
    for x in args:
        total=total+x;
    return total;'''
  

print(sum("1","apple","1","20","3","4","5",100))
    