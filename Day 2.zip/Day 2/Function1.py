def function1(age):
    print('hello....')
    if(age>=18):
        print("ok")
    else:
        print("not ok");
    print("end of function");


function1(int(input("enter age")))

color=["red","green","blue"]
for i,d in enumerate(color):
    print(i,d);
for x in range(len(color)):
    print("color[%d]=%s"  %(x,color[x]));




