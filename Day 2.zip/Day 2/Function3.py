'''def display(**kwargs):
    for key,value in kwargs.items():
        print(key)
        print(value);

display(name="manisha",age=33,sal=12323.55,loc="Pune")
def add(a,b=10):
    print(a+b);'''


cube=lambda a:a*a*a
print(cube(3))

square=lambda a,b:a+b ;print ('ass')
print(square(2,3))

hello=lambda :print ('helloooo')
hello()





    